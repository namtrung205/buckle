var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// ../../packages/plugin-sdk/dist/contract.js
var PLUGIN_API_VERSION = 1;
var RPC_VERSION = PLUGIN_API_VERSION;
var DEFAULT_CALL_TIMEOUT_MS = 5e3;
var PLUGIN_PERMISSIONS = [
  "model.write.nodes",
  "model.write.members",
  "model.write.shells",
  "model.write.loads",
  "model.write.supports",
  "model.write.materials",
  "model.write.sections",
  "model.write.grids",
  "model.write.levels",
  "model.write.groups",
  "model.write.selectionSets",
  "model.write.parametric",
  "model.delete.nodes",
  "model.delete.members",
  "model.delete.shells",
  "model.delete.loads",
  "model.delete.supports",
  "model.delete.materials",
  "model.delete.sections",
  "model.delete.grids",
  "model.delete.levels",
  "model.delete.groups",
  "model.delete.selectionSets",
  "model.delete.parametric",
  "workspace.writeSelection",
  "workspace.visibility"
];
var PLUGIN_SURFACE_PERMISSIONS = [
  "model.read",
  "workspace.readSelection",
  "workspace.writeSelection",
  "ui.panel",
  "ui.notify",
  "viewport.pick",
  "viewport.draw",
  "viewport.zoomTo",
  "storage.project",
  "storage.local"
];
var ALL_PLUGIN_PERMISSIONS = [.../* @__PURE__ */ new Set([...PLUGIN_PERMISSIONS, ...PLUGIN_SURFACE_PERMISSIONS])];
var MAX_RPC_MESSAGE_BYTES = 256 * 1024;

// ../../packages/plugin-sdk/dist/client.js
var RpcCallError = class extends Error {
  constructor(code, message) {
    super(message);
    __publicField(this, "code");
    this.name = "RpcCallError";
    this.code = code;
  }
};
var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var PluginPanelClient = class _PluginPanelClient {
  constructor(options) {
    __publicField(this, "transport");
    __publicField(this, "pending", /* @__PURE__ */ new Map());
    __publicField(this, "nextId", 0);
    __publicField(this, "timeoutMs");
    __publicField(this, "disposed", false);
    __publicField(this, "unsubscribe");
    this.transport = options.transport;
    this.timeoutMs = options.callTimeoutMs ?? DEFAULT_CALL_TIMEOUT_MS;
    this.unsubscribe = this.transport.subscribe((message) => this.onMessage(message));
  }
  /** Standard panel transport: `window.parent` + the window message event. */
  static forParentWindow(timeoutMs) {
    return new _PluginPanelClient({
      transport: {
        post: (message) => window.parent.postMessage(message, "*"),
        subscribe: (listener) => {
          const handler = (event) => listener(event.data);
          window.addEventListener("message", handler);
          return () => window.removeEventListener("message", handler);
        }
      },
      ...timeoutMs !== void 0 ? { callTimeoutMs: timeoutMs } : {}
    });
  }
  /** Call one host method; rejects with `RpcCallError` on structured failure,
   *  timeout or protocol garbage. Unknown methods fail closed client-side. */
  call(method, params) {
    if (this.disposed)
      return Promise.reject(new RpcCallError("DISPOSED", "Client was disposed"));
    const id = `call-${++this.nextId}`;
    const envelope = params === void 0 ? { v: RPC_VERSION, id, method } : { v: RPC_VERSION, id, method, params };
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new RpcCallError("TIMEOUT", `${method} timed out`));
      }, this.timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      try {
        this.transport.post(envelope);
      } catch (error) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(error instanceof Error ? error : new RpcCallError("REJECTED", String(error)));
      }
    });
  }
  query() {
    return this.call("model.query");
  }
  execute(command, expectedModelRevision) {
    return this.call("model.execute", expectedModelRevision === void 0 ? { command } : { command, expectedModelRevision });
  }
  notify(message, kind = "info") {
    return this.call("ui.notify", { message, kind }).then(() => void 0);
  }
  openPanel(panelId) {
    return this.call("ui.openPanel", { panelId }).then(() => void 0);
  }
  storageGet(scope, key) {
    return this.call("storage.get", { scope, key });
  }
  storageSet(scope, key, value) {
    return this.call("storage.set", { scope, key, value }).then(() => void 0);
  }
  storageDelete(scope, key) {
    return this.call("storage.delete", { scope, key }).then(() => void 0);
  }
  storageKeys(scope) {
    return this.call("storage.keys", { scope }).then((value) => Array.isArray(value) ? value : []);
  }
  /** Reject all pending calls and detach the listener (panel unmount). */
  dispose() {
    if (this.disposed)
      return;
    this.disposed = true;
    this.unsubscribe();
    for (const [id, pending] of this.pending) {
      clearTimeout(pending.timer);
      pending.reject(new RpcCallError("DISPOSED", "Client was disposed"));
      this.pending.delete(id);
    }
  }
  onMessage(message) {
    if (!isRecord(message) || message.v !== RPC_VERSION || typeof message.id !== "string")
      return;
    const pending = this.pending.get(message.id);
    if (!pending)
      return;
    this.pending.delete(message.id);
    clearTimeout(pending.timer);
    if (message.ok === true)
      pending.resolve(message.value);
    else if (isRecord(message.error) && typeof message.error.code === "string") {
      pending.reject(new RpcCallError(String(message.error.code), String(message.error.message ?? "Rejected")));
    } else
      pending.reject(new RpcCallError("REJECTED", "Malformed result envelope"));
  }
};

// ../../packages/plugin-sdk/dist/worker.js
var isRecord2 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
function createWorkerPlugin(handlers, port = globalThis) {
  const commandIds = Object.keys(handlers);
  const api = new PluginPanelClient({
    transport: {
      post: (message) => port.postMessage(message),
      subscribe: (listener) => {
        const onMessage = (event) => listener(event.data);
        port.addEventListener("message", onMessage);
        return () => port.removeEventListener("message", onMessage);
      }
    }
  });
  let disposed = false;
  const onCommand = (event) => {
    const message = event.data;
    if (!isRecord2(message) || message.v !== RPC_VERSION || message.kind !== "command.invoke")
      return;
    if (typeof message.id !== "string" || typeof message.commandId !== "string")
      return;
    const request = message;
    const handler = Object.prototype.hasOwnProperty.call(handlers, request.commandId) ? handlers[request.commandId] : void 0;
    if (!handler) {
      port.postMessage({
        v: RPC_VERSION,
        kind: "command.result",
        id: request.id,
        ok: false,
        error: { code: "UNKNOWN_COMMAND", message: `Unknown command ${request.commandId}` }
      });
      return;
    }
    void Promise.resolve().then(() => handler(api)).then((value) => {
      if (!disposed)
        port.postMessage({ v: RPC_VERSION, kind: "command.result", id: request.id, ok: true, value });
    }, (error) => {
      if (!disposed)
        port.postMessage({
          v: RPC_VERSION,
          kind: "command.result",
          id: request.id,
          ok: false,
          error: { code: "COMMAND_FAILED", message: error instanceof Error ? error.message : String(error) }
        });
    });
  };
  port.addEventListener("message", onCommand);
  port.postMessage({ v: RPC_VERSION, kind: "plugin.ready", commands: commandIds });
  return {
    api,
    dispose: () => {
      if (disposed)
        return;
      disposed = true;
      port.removeEventListener("message", onCommand);
      api.dispose();
    }
  };
}

// ../../packages/plugin-sdk/dist/manifest.js
var KNOWN_PERMISSIONS = new Set(ALL_PLUGIN_PERMISSIONS);

// ../../packages/plugin-sdk/dist/signature.js
var encoder = new TextEncoder();
var decoder = new TextDecoder("utf-8", { fatal: true });

// ../../packages/plugin-sdk/dist/bundle.js
var PLUGIN_BUNDLE_MAX_BYTES = 8 * 1024 * 1024;
var PLUGIN_ENTRY_MAX_BYTES = 1 * 1024 * 1024;
var PLUGIN_BUNDLE_MAX_EXPANDED_BYTES = 16 * 1024 * 1024;

// src/worker.ts
var plugin = createWorkerPlugin({
  "com.buckle.examples.hello.run": async (api) => {
    await api.openPanel("com.buckle.examples.hello.panel");
  }
});
void plugin.api.query().then(async (snapshot) => {
  await plugin.api.notify(
    `Hello Buckle! ${snapshot.nodes.length} nodes, ${snapshot.members.length} members`,
    "success"
  );
}).catch((error) => {
  void plugin.api.notify(`Hello Buckle error: ${String(error)}`, "error");
});
